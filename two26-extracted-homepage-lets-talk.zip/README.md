# Extracted Two26 Homepage + Let's Talk

These are extracted from the supplied Webflow ZIP.

- `homepage.html`: the original header/navigation + complete homepage `<main>` + footer.
- `lets-talk.html`: the original `.contact-page` overlay and its animation code.
- `styles.css`: original Webflow stylesheet.
- `js/`: original GSAP/Webflow/Lenis dependencies.
- `images/` and `fonts/`: local assets referenced by the extracted pages.

Important:
- The source uses Webflow-generated classes and custom inline GSAP scripts.
- The curved hero marquee is the `.hero-marquee` SVG/textPath component in `homepage.html`.
- The "THIS IS OUR THING" section uses `.section-services` and `initServicesPathAnimation()`.
- Testimonials use `.section-testimonials` and `initTestimonialsStack()`.
- Let's Talk is an overlay inside the original page, powered by `initTwo26ContactModal()`.
- Replace the original Two26 text, links, colors, and content for your new site.
